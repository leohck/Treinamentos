package com.example.salario;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.support.v4.app.NavUtils;

public class Tela extends Activity implements OnClickListener{

	EditText salario, agua, luz, telefone;
	Button calcular;
	TextView resultado;
	
	
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout);
        salario = (EditText)	findViewById(R.id.caixaSalario);
        agua 	= (EditText)	findViewById(R.id.caixaAgua);
        luz     = (EditText)	findViewById(R.id.caixaLuz);
        telefone= (EditText)	findViewById(R.id.caixaTelefone);
        calcular= (Button)		findViewById(R.id.botao);
        resultado=(TextView)	findViewById(R.id.caixaResultado);
        calcular.setOnClickListener(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.layout, menu);
        return true;
    }

	public void onClick(View v) {
		// TODO Auto-generated method stub
		double valorSalario, valorAgua, valorLuz, valorTelefone, valorResultado;
		valorSalario = Double.parseDouble( salario.getText().toString() );
		valorAgua 	 = Double.parseDouble( agua.getText().toString() );
		valorLuz	 = Double.parseDouble( luz.getText().toString() );
		valorTelefone= Double.parseDouble( telefone.getText().toString() );
		
		valorResultado=( valorSalario - (valorAgua + valorLuz + valorTelefone));
		
		resultado.setText("Sobrou : "+ valorResultado + " apos pagar as contas"); 	}

   
}
