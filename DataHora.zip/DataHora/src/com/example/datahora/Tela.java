	package com.example.datahora;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TextView;
import android.widget.TimePicker;
import android.support.v4.app.NavUtils;

public class Tela extends Activity implements OnClickListener{

	DatePicker dt;
	TimePicker hr;
	Button     bt;
	TextView   cx;
	
	
	
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout);
        
        dt = (DatePicker)	findViewById(R.id.data);
        hr = (TimePicker)	findViewById(R.id.hora);
        bt = (Button)		findViewById(R.id.botao);
        cx = (TextView)		findViewById(R.id.caixa);
        
        bt.setOnClickListener(this);
        
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.layout, menu);
        return true;
    }

	public void onClick(View v) {
		// TODO Auto-generated method stub
		
	
	String msg ;
	
	msg = "Voce agendou para o dia: ";
	
	msg = msg + dt.getDayOfMonth() + "/" + dt.getMonth() + "/" + dt.getYear();
	
	msg = msg + " as " + hr.getCurrentHour()+ ":" + hr.getCurrentMinute();
	
	cx.setText(msg);
	}
}
