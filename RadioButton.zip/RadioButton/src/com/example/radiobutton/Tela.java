package com.example.radiobutton;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.support.v4.app.NavUtils;

public class Tela extends Activity implements OnClickListener{

	EditText    sal;
	RadioButton a5, a10, a15;
	Button 		bt;
	TextView 	cx;
	
	
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_tela);
        
        sal = (EditText)	findViewById(R.id.caixaSalario);
        a5  = (RadioButton)	findViewById(R.id.aumento5);
        a10 = (RadioButton)	findViewById(R.id.aumento10);
        a15 = (RadioButton)	findViewById(R.id.aumento15);
        bt  = (Button)		findViewById(R.id.botao);
        cx  = (TextView)	findViewById(R.id.caixaMostrar);
        
        bt.setOnClickListener(this);
        
    }
   
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.layout_tela, menu);
        return true;
    }

	public void onClick(View v) {
		// TODO Auto-generated method stub
		double 	  salario ;
		salario = Double.parseDouble( sal.getText().toString() );
		
		if (a5.isChecked())
		{
			salario = ((salario * 5)/100) + salario;
		}
			
		if (a10.isChecked())
		{
			salario = ((salario * 10)/100) + salario;
		}
		
		if (a15.isChecked())
		{
			salario = ((salario * 15)/100) + salario;
		}
		
		cx.setText("Sal�rio Novo: "+salario);
	}

    
}
