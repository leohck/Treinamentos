/** Automatically generated file. DO NOT MODIFY */
package com.example.radiobutton;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}