package com.example.produto;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;
import android.support.v4.app.NavUtils;

public class MainActivity extends Activity implements OnClickListener {

	CheckBox arroz, leite, carne, feijao;
	Button botao;
	TextView resultado;
	
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        arroz 		= (CheckBox)	findViewById(R.id.check1);
        leite 		= (CheckBox)	findViewById(R.id.check2);
        carne 		= (CheckBox)	findViewById(R.id.check3);
        feijao 		= (CheckBox)	findViewById(R.id.check4);
        botao 		= (Button)		findViewById(R.id.botao);
        resultado 	= (TextView)	findViewById(R.id.caixaResultado);
        
        botao.setOnClickListener(this);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.activity_main, menu);
        return true;
    }

	public void onClick(View v) {
		///////////////////////////////
		if(arroz.isChecked())
		{
			resultado.setText("TOTAL: R$2,69");
		}
			
		else if(leite.isChecked())
		{
			resultado.setText("");
			resultado.setText("TOTAL: R$5,00");
		}
		else if(carne.isChecked())
		{
			resultado.setText("");
			resultado.setText("TOTAL: R$9,70");
		}
		else if(feijao.isChecked())
		{
			resultado.setText("");
			resultado.setText("TOTAL: R$2,30");
		}
		/////////////////////////////////////////	
		else if(arroz.isChecked() && leite.isChecked())
		{
			resultado.setText("");
			resultado.setText("TOTAL: R$7,69");
		}
		else if(arroz.isChecked() && carne.isChecked())
		{
			resultado.setText("");
			resultado.setText("TOTAL: R$12,93");
		}
		else if(arroz.isChecked() && feijao.isChecked())
		{
			resultado.setText("");
			resultado.setText("TOTAL: R$4,99");
		}
		else if(leite.isChecked() && carne.isChecked())
		{
			resultado.setText("");
			resultado.setText("TOTAL: R$14,70");
		}
		else if(leite.isChecked() && feijao.isChecked())
		{
			resultado.setText("");
			resultado.setText("TOTAL: R$8,30");
		}
		else if(carne.isChecked() && feijao.isChecked())
		{
			resultado.setText("");
			resultado.setText("TOTAL: R$12,00");
		}
		//////////////////////////////////////////////
		else if(arroz.isChecked() && leite.isChecked() && carne.isChecked())
		{
			resultado.setText("");
			resultado.setText("TOTAL: R$17,39");
		}
		else if(arroz.isChecked() && leite.isChecked() && feijao.isChecked())
		{
			resultado.setText("");
			resultado.setText("TOTAL: R$9,99");
		}
		else if(arroz.isChecked() && leite.isChecked() && carne.isChecked() && feijao.isChecked())
		{
			resultado.setText("");
			resultado.setText("TOTAL: R$19,69");
		}
		else if(leite.isChecked() && carne.isChecked() && feijao.isChecked())
		{
			resultado.setText("");
			resultado.setText("TOTAL: R$17,00");
		}
		else
		{
			resultado.setText("");
		}

		
	}

    
}
